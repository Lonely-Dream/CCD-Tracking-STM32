#ifndef _SteeringGear_H
#define _SteeringGear_H

/*
Description:
Pins:
PA2  ����ź��� TIM2 ch3

*/

#include "system.h"

void SteeringGearInit(void);
void setSteeringGearAngle(int angle);
#endif
